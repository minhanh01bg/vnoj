#include<bits/stdc++.h>
using namespace std;

const int N = 1e7 + 12;
const long long Mod = 1e9 + 7;
const long long oo = 1e18;

#define fi first
#define se second
#define pb push_back
#define mp make_pair

#define Bit(a, i) (((int)a>>((int)i - 1))&1)
#define dBit(x) __builtin_popcount((int)x)
#define FOR(i, a, b) for (int _ = a, __ = b, i = _; i <= __; i++)
#define FORD(i, a, b) for (int _ = a, __ = b, i = _; i >= __; i--)
#define FIX(n, x) cout << setprecision((int)n) << fixed << x << "\n";

int dx[] = {-1, 0, 0, 1};
int dy[] = {0, -1, 1, 0};

int n, top;
long long a[N], L[N], R[N], D[N];
pair<long long, int> p[N], q[N];

main(){
    cin.tie(0); cout.tie(0);
    ios_base::sync_with_stdio(false);

    cin >> n;
    FOR (i, 1, n) cin >> a[i];

    a[0] = oo;
    D[0] = 0; top = 0;
    FOR (i, 1, n) {
    	while (a[i] > a[D[top]]) {
    		R[D[top]] = i; top--;
    	}	
    	D[++top] = i;
    }

    D[0] = 0, top = 0;
    FORD (i, n, 1) {
    	while (a[i] > a[D[top]]) {
    		L[D[top]] = i; top--;
    	}
    	D[++top] = i;
    }

    
    p[1] = mp(a[1], 1);
    FOR (i, 2, n) {
    	p[i] = p[i - 1];
    	if (a[i] >= p[i].fi) p[i] = mp(a[i], i);
    }

    q[n] = mp(a[n], n);
    FORD (i, n - 1, 1) {
    	q[i] = q[i + 1];
    	if (a[i] >= q[i].fi) q[i] = mp(a[i], i);
    }

    long long ret = 0;
    FOR (i, 1, n) {
    	long long x = min(p[i].fi, q[i].fi);
    	ret += x - a[i];
    }

    long long ans = ret;

    FOR (i, 1, n) {
    	if (a[i] < p[i].fi && a[i] < q[i].fi) continue;
    	if (a[i] >= p[i].fi && a[i] >= q[i].fi) continue;
    	long long tmp = ret;
    	long long x = a[i] + 1;
    	
    	if (x <= p[i].fi) {
    		tmp += i - L[i] - 1;
    	}
    	if (x <= q[i].fi) {
    		tmp += R[i] - i - 1;
    	}

   		ans = max(ans, tmp);
    }

    cout << ans << "\n";

}
