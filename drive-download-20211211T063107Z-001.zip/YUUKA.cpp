#include <bits/stdc++.h>

#define lli long long
#define ull unsigned long long

#define FOR(i, a, b) for(int i=a, _n=b; i<=_n; ++i)
#define REP(i, _n) for(int i=0; i<_n; ++i)

using namespace std;

ull b[4][4], a[4][4], s[25], n[25];

ull h(lli x, int k) {
    if (k == 1) return b[x+1][3];

    int i; k = k-1;
    i = x / n[k]; x %= n[k];

    return b[i][3] * s[k] // Tổng phần không bị cắt = Tổng số 1 trong mảng a * Tổng số 1 trong ma trận 3^(k-1) x 3(k-1)
        + (b[i+1][3] - b[i][3]) * h(x, k); // Tính phần bị cắt ngang tại x, nhân với số vùng bị cắt
}
ull v(lli y, int k) {
    if (k == 1) return b[3][y+1];

    int j; k = k-1;
    j = y / n[k]; y %= n[k];

    return b[3][j] * s[k] // Tổng phần không bị cắt = Tổng số 1 trong mảng a * Tổng số 1 trong ma trận 3^(k-1) x 3(k-1)
        + (b[3][j+1] - b[3][j]) * v(y, k); // Tính phần cắt dọc tại y, nhân với số vùng bị cắt
}
ull f(lli x, lli y, int k) {
    if (x < 0 || y < 0) return 0;
    if (k == 1) return b[x+1][y+1];

    int i, j; k = k-1;
    i = x / n[k]; x %= n[k];
    j = y / n[k]; y %= n[k];

    return b[i][j] * s[k] // Tổng phần không bị cắt = Tổng số 1 trong mảng a * Tổng số 1 trong ma trận 3^(k-1) x 3(k-1)
        + a[i][j] * f(x, y, k) // Tính phần góc bị cắt
        + (b[i][j+1] - b[i][j]) * v(y, k) // Tính phần cắt dọc tại y, nhân với số vùng bị cắt
        + (b[i+1][j] - b[i][j]) * h(x, k); // Tính phần bị cắt ngang tại x, nhân với số vùng bị cắt
}
int main()
{
    ios::sync_with_stdio(); cin.tie(0);

    REP(i, 3) REP(j, 3) cin >> a[i][j];
    REP(i, 4) REP(j, 4) REP(x, i) REP(y, j) b[i][j] += a[x][y];
    // b[i][j] = tổng các số a[x][y] trong đoạn 0<=x<i , 0<=y<j

    s[0] = n[0] = 1;
    FOR(i, 1, 20) s[i] = s[i-1] * b[3][3], n[i] = n[i-1] * 3;
    // s[i] = tổng các số 1 trong ma trận 3^i x 3^i
    // n[i] = 3^i

    lli x, y, u, v; int q, k;
    cin >> q; while (q--) {

        cin >> x >> y >> u >> v;

        k = 1; while (n[k] <= u || n[k] <= v) ++k;
        // Tìm k nhỏ nhất sao cho ma trận 3^k x 3^k bao hình chữ nhật (x, y, u, v)

        cout << f(u, v, k) - f(x-1, v, k) - f(u, y-1, k) + f(x-1, y-1, k) << '\n';
        // Tính tổng số 1 trong hình chữ nhật (x, y, u, v)
    }
}
