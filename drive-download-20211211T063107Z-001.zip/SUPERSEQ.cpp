#include <bits/stdc++.h>
using namespace std;
#define int long long
#define rep(i, a, b) for(int i = a; i < (b); ++i)
#define all(x) begin(x), end(x)
#define sz(x) (int)(x).size()
#define X first.first
#define Y first.second
#define Z second.first
#define T second.second
typedef long long ll;
typedef pair<int, int> pii;
typedef vector<int> vi;
typedef pair<pii,pii> has;

const int oo1 = 1e9+7;
const int oo2 = 1e9+9;
const int oo3 = 1e9+31;
const int oo4 = 1e9+33;
const int maxn = 100000;
const int base = 2*maxn+1;

has powB[maxn+2];

has patterns[maxn+1];


int n;
int a[maxn+1];
has f[maxn+1];

has ad(has a, has b) {
	return {{(a.X+b.X)%oo1,(a.Y+b.Y)%oo2}, {(a.Z+b.Z)%oo3, (a.T+b.T)%oo4}};
}

has ad(has a,int b) {
	return {{(a.X+b)%oo1,(a.Y+b)%oo2}, {(a.Z+b)%oo3, (a.T+b)%oo4}};
}

has multi(has a, has b) {
	return {{(a.X*b.X)%oo1,(a.Y*b.Y)%oo2}, {(a.Z*b.Z)%oo3, (a.T*b.T)%oo4}};
}

has multi(has a, int b) {
	return {{(a.X*b)%oo1,(a.Y*b)%oo2}, {(a.Z*b)%oo3, (a.T*b)%oo4}};
}

has sub(has a, has b) {
	return {{(a.X-b.X+oo1*oo1)%oo1,(a.Y-b.Y+oo2*oo2)%oo2}, {(a.Z-b.Z+oo3*oo3)%oo3, (a.T-b.T+oo4*oo4)%oo4}};
}

has get_has(int x,int y) {
	return sub(f[y],f[x-1]);
}

void generatePattern() {
	has cur = {{0ll,0ll},{0ll,0ll}};
	has tmp = {{1ll,1ll},{1ll,1ll}};
	powB[0] = tmp;

	rep(i,1,n+2) {
		tmp = multi(tmp, base);
		powB[i] = tmp;
		cur = ad(cur, multi(tmp, i));
		if (i<=n) patterns[i]=cur;
	}
}



main() {
	cin.tie(0)->sync_with_stdio(0);
	cin.exceptions(cin.failbit);
	cin >> n;
	rep(i,1,n+1) cin >> a[i];
	generatePattern();

	f[0] = {{0ll,0ll},{0ll,0ll}};
	rep(i,1,n+1) f[i] = ad(f[i-1], (a[i] <= n) ? (powB[a[i]]) : (powB[n+1]));

	int res = 0;
	rep(i,1,n+1) {
		int len = 1;
		int m = 1;
		while (i+len-1 <= n) {
			if (patterns[m] == get_has(i, i+len-1)) {
				//cout << i << ' ' << i+len-1 << endl;
				res++;
			}
			m++; len+=m;
		}
		//cout << m << endl;
	}

	cout << res;
}
